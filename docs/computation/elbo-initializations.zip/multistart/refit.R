# Refit the fixed-training-data multistart experiment with the bundled engine.
# Run from any directory using a path to this script. See README.md for arguments.

load_engine <- function(here) {
  if (!requireNamespace("digest",quietly=TRUE)) stop("Install the R package 'digest' before refitting.")
  source_dir <- normalizePath(file.path(here,"..","source"), mustWork=TRUE)
  fingerprints <- read.csv(file.path(here,"fitting-sources.csv"),stringsAsFactors=FALSE)
  stopifnot(all(unname(tools::md5sum(file.path(source_dir,fingerprints$member)))==fingerprints$md5))
  # Only the preprocessing, initializer, controls and coefficient-wise engine
  # enter these fits. The original data generator is unnecessary with fixed x,y.
  sys.source(file.path(source_dir,"main_simulation.R"),.GlobalEnv)
  for (path in c("study/extensions/jeffreys_c1/stochastic_cavi_nonlinear/model.R",
                 "study/extensions/cavi_benchmark/network.R","study/R/study_utils.R",
                 "study/extensions/relu_snr1_v1/run.R","engine/engine.R","tail_audit.R"))
    sys.source(file.path(source_dir,path),.GlobalEnv)
  observe_tail_engine(coef_v3_load(file.path(source_dir,"engine")))
}

read_design <- function(here) {
  inputs <- file.path(here,"inputs")
  design <- read.csv(file.path(inputs,"manifest.csv"),stringsAsFactors=FALSE)
  stopifnot(identical(design$setting,paste0("C",1:9)),
    identical(design$cell,c(1:8,2L)),identical(design$snr,c(rep(3L,8),1L)),
    all(design$replicate==1L))
  design$file <- file.path(inputs,design$input)
  stopifnot(all(unname(tools::md5sum(design$file))==design$input_md5))
  for (i in seq_len(nrow(design))) {
    d <- readRDS(design$file[i])
    stopifnot(identical(names(d),c("x","y")),is.matrix(d$x),
      all(dim(d$x)==c(design$n[i],design$p[i])),length(d$y)==design$n[i],
      all(is.finite(d$x)),all(is.finite(d$y)))
  }
  jobs <- do.call(rbind,lapply(1:10,function(i) transform(design,start=i)))
  jobs$initial_seed <- mapply(function(cell,start) {
    if (start==1L) return(tabnn_seed("cavi100_v1",cell,1L,"initial"))
    tabnn_seed("r28_multistart",cell,1L,start,"initial")
  },jobs$cell,jobs$start)
  jobs$vi_seed <- vapply(jobs$cell,function(cell) tabnn_seed("relu100_v1",cell,1L,"variational"),1L)
  jobs
}

method_codes <- c(G="g",GL="hs",GLT="glt")
checkpoint_files <- function(job,out) {
  setNames(file.path(out,sprintf("%s_start%02d_%s.rds",job$setting,job$start,names(method_codes))),
           names(method_codes))
}

checked <- function(file,job,prior) {
  z <- readRDS(file)
  stopifnot(identical(z$setting,job$setting),identical(z$start,job$start),
    identical(z$prior,prior),identical(z$input_md5,job$input_md5),
    identical(z$initial_seed,job$initial_seed),identical(z$vi_seed,job$vi_seed),
    length(z$init_sha)==1L, grepl("^[0-9a-f]{64}$",z$init_sha),
    nrow(z$trace)==61L,identical(as.integer(z$trace$outer),0:60),
    all(is.finite(z$trace$elbo)),all(is.finite(z$trace$elbo_mcse)),
    all(is.finite(unlist(z$endpoint[c("value","mcse")]))),
    length(z$endpoint$value)==1L,length(z$endpoint$mcse)==1L)
  z
}

refit <- function(job) {
  files <- checkpoint_files(job,.output)
  done <- file.exists(files)
  previous <- lapply(names(files)[done],function(p) checked(files[[p]],job,p)$init_sha)
  if (all(done)) return(invisible(TRUE))
  d <- readRDS(job$file)
  prep <- sn_preprocess(d$x,d$y)
  x <- sn_x(d$x,prep)
  y <- (d$y-prep$y_center)/prep$y_scale
  W <- cb_train(x,y,c(25L,25L),job$initial_seed,600L)
  init_sha <- digest::digest(W,algo="sha256")
  if (length(previous)) stopifnot(all(unlist(previous)==init_sha))
  for (prior in names(files)[!done]) {
    fit <- coef_v3_fit(d$x,d$y,W,method_codes[[prior]],e=.engine,
                       seed=job$vi_seed,control=snr1_control)
    stopifnot(fit$outer==60L,nrow(fit$weight_steps)==600L,fit$config$prior==prior)
    z <- list(setting=job$setting,start=job$start,prior=prior,input_md5=job$input_md5,
      initial_seed=job$initial_seed,vi_seed=job$vi_seed,init_sha=init_sha,
      trace=fit$trace,endpoint=fit$endpoint[c("value","mcse")])
    v3_save_once(z,files[[prior]])
    checked(files[[prior]],job,prior)
  }
  invisible(TRUE)
}

export_completed <- function(jobs,out) {
  traces <- list()
  endpoints <- list()
  for (i in seq_len(nrow(jobs))) {
    job <- jobs[i,,drop=FALSE]
    files <- checkpoint_files(job,out)
    if (!all(file.exists(files))) return(invisible(FALSE))
    starts <- character()
    for (prior in names(files)) {
      z <- checked(files[[prior]],job,prior)
      starts <- c(starts,z$init_sha)
      id <- data.frame(setting=job$setting,prior=prior,start=job$start,cell=job$cell,
        snr=job$snr,replicate=1L,source="refit",data_md5=job$original_data_md5,
        initial_seed=job$initial_seed,vi_seed=job$vi_seed,init_sha=z$init_sha)
      tr <- z$trace
      traces[[length(traces)+1L]] <- data.frame(id,cycle=tr$outer,elbo=tr$elbo,
        mcse=tr$elbo_mcse,gain=tr$gain,paired_gain_mcse=tr$paired_gain_mcse)
      endpoints[[length(endpoints)+1L]] <- data.frame(id,endpoint=z$endpoint$value,
        endpoint_mcse=z$endpoint$mcse,final_monitor=tail(tr$elbo,1L))
    }
    stopifnot(length(unique(starts))==1L)
  }
  write_exact <- function(parts,file) {
    x <- do.call(rbind,parts)
    for (name in names(x)) if(is.double(x[[name]])) x[[name]] <- sprintf("%.17g",x[[name]])
    write.csv(x,file.path(out,file),row.names=FALSE,na="NA")
  }
  write_exact(traces,"traces.csv")
  write_exact(endpoints,"endpoints.csv")
  invisible(TRUE)
}

main <- function(script,args) {
  here <- dirname(script)
  workers <- if (length(args)) suppressWarnings(as.integer(args[1])) else 1L
  check_only <- identical(args,"--check")
  if (!check_only && (length(args)>3L || is.na(workers) || workers<1L)) {
    stop("Use refit.R [workers [C1..C9|all [1..10|all]]] or refit.R --check.")
  }
  Sys.setenv(OPENBLAS_NUM_THREADS=1,OMP_NUM_THREADS=1,MKL_NUM_THREADS=1,BLIS_NUM_THREADS=1)
  engine <- load_engine(here)
  jobs <- read_design(here)
  if (check_only) {
    cat("Verified nine fixed training sets, 90 matched starts, and the bundled source.\n")
    return(invisible(TRUE))
  }
  selected <- jobs
  if (length(args)>=2L && args[2]!="all") selected <- selected[selected$setting==args[2],]
  if (length(args)>=3L && args[3]!="all") {
    start <- suppressWarnings(as.integer(args[3]))
    if (is.na(start) || !start %in% 1:10) stop("Choose a start from 1 through 10.")
    selected <- selected[selected$start==start,]
  }
  if (!nrow(selected)) stop("Choose a design from C1 through C9.")
  out <- file.path(here,"refitted")
  dir.create(out,showWarnings=FALSE)
  units <- lapply(seq_len(nrow(selected)),function(i)selected[i,,drop=FALSE])
  workers <- min(workers,length(units))
  if (workers==1L) {
    assign(".engine",engine,.GlobalEnv)
    assign(".output",out,.GlobalEnv)
    invisible(lapply(units,refit))
  } else {
    cluster <- parallel::makePSOCKcluster(workers)
    on.exit(parallel::stopCluster(cluster),add=TRUE)
    parallel::clusterCall(cluster,function(script,here,out) {
      sys.source(script,.GlobalEnv)
      assign(".engine",load_engine(here),.GlobalEnv)
      assign(".output",out,.GlobalEnv)
      TRUE
    },script,here,out)
    invisible(parallel::parLapplyLB(cluster,units,refit,chunk.size=1L))
  }
  if (export_completed(jobs,out)) cat("Wrote the 270-fit trace and endpoint tables.\n")
  else cat("Selected fits are complete. Checkpoints are in refitted/.\n")
}

if (sys.nframe()==0L) {
  input <- grep("^--file=",commandArgs(FALSE),value=TRUE)
  if(length(input)!=1L) stop("Run this script with Rscript.")
  main(normalizePath(sub("^--file=","",input)),commandArgs(trailingOnly=TRUE))
}
