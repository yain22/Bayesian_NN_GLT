# ELBO sensitivity to initialization

The nine regression settings use the first simulated training sample for each design. C1–C8 have training signal-to-noise ratio 3. C9 uses the C2 additive design at training signal-to-noise ratio 1. Each network has two hidden layers of 25 units. The ten starts change the initial weights. Training data, preprocessing, fitting budget and variational random seed are fixed within each setting.

Each start first trains an unpenalized network for 600 updates. Its fitted weights initialize the Gaussian means for all three priors. G, GL and GLT then each take 60 cycles of ten weight proposals. Monitoring uses 32 fixed antithetic pairs at cycles 0 through 60. A separate estimate of the final objective uses 256 fresh antithetic draws. The `elbo` column at cycle 60 is the final monitored value. The independent estimate is `endpoint` in `endpoints.csv`.

The `inputs` directory contains the original synthetic training predictor matrices and response vectors. Its manifest gives the setting, dimensions, SNR and file checksums. The two C2 settings share the original predictor and noise draws and the pretraining seed for each matched start. Their responses differ. The `fitting-sources.csv` manifest identifies the routines in `../source` used for these fits.

## Reproduce the figure from saved results

From this directory, run the following commands with Python, Matplotlib, NumPy and PyMuPDF installed.

```sh
python plot_traces.py traces.csv v3_elbo_current.pdf endpoint-spread.csv
python verify_plot.py traces.csv v3_elbo_current.pdf endpoint-spread.csv
```

## Refit from the training inputs

Extract the full replication archive so that `continuous/source` is beside `continuous/multistart`. Run the following commands from `continuous/multistart`. They use R and the `digest` package.

Verify the inputs, seed schedule and fitting sources without fitting models.

```sh
Rscript --vanilla refit.R --check
```

Refit one matched triplet (C1, start 1) with one worker.

```sh
Rscript --vanilla refit.R 1 C1 1
```

Refit all 270 models with four workers. The first argument controls the worker count. Omitting all arguments runs the full experiment with one worker.

```sh
Rscript --vanilla refit.R 4
```

The script saves each completed fit’s objective trace and independent endpoint estimate under `refitted/`. Rerunning the command validates existing checkpoints and completes missing fits. Once all 270 fits are present, `refitted/traces.csv` contains 16,470 setting–prior–start–cycle observations and `refitted/endpoints.csv` contains 270 independent endpoint estimates. The `source` column in a fresh run is `refit`. In the reported experiment, `original` identifies the 27 previously completed fits at start 1 and `new` identifies the 243 additional fits. Different numerical libraries can produce floating-point differences, particularly after many gradient steps.
