"""Draw 270 monitored ELBO trajectories from the recorded optimization output."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np


SETTINGS = tuple(f"C{i}" for i in range(1, 10))
PRIORS = ("G", "GL", "GLT")
DESIGNS = ("Linear", "Reference\nadditive", "Interaction", "Smaller\nsample",
           "Larger\nsample", "500\npredictors", "30 active\ninputs",
           "Higher\ncorrelation", "Lower signal-\nto-noise")
COLOURS = ("#27618A", "#AE512C", "#25765E", "#815985", "#826513")
STYLES = ("solid", (0, (3, 1.6)))
SIZE = (6.6, 7.14)


def read_traces(filename):
    """Return levels in setting, prior, start, cycle order. Require every recorded cycle."""
    shape = (len(SETTINGS), len(PRIORS), 10, 61)
    values = np.full(shape, np.nan)
    with Path(filename).open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.DictReader(stream)
        needed = {"setting", "prior", "start", "cycle", "elbo"}
        if not needed.issubset(rows.fieldnames or ()):
            raise ValueError("Missing required columns: " + ", ".join(sorted(needed - set(rows.fieldnames or ()))))
        for row in rows:
            i, j = SETTINGS.index(row["setting"]), PRIORS.index(row["prior"])
            k, t = int(row["start"]), int(row["cycle"])
            value = float(row["elbo"])
            if not (1 <= k <= 10 and 0 <= t <= 60 and np.isfinite(value)):
                raise ValueError(f"Invalid start, cycle, or ELBO on line {rows.line_num}")
            if np.isfinite(values[i, j, k-1, t]):
                raise ValueError(f"Duplicate setting/prior/start/cycle on line {rows.line_num}")
            values[i, j, k-1, t] = value
    if not np.isfinite(values).all():
        raise ValueError(f"{np.isnan(values).sum()} of 16,470 expected monitor values are missing")
    if values.max() >= 0:
        raise ValueError("Log spacing in negative ELBO magnitude requires strictly negative monitored ELBOs")
    return values


def write_summary(values, filename):
    """Nine rows. All entries refer to the recorded cycle-60 monitor, in ELBO units."""
    stats = ("min", "median", "max", "range")
    with Path(filename).open("w", newline="", encoding="utf-8") as stream:
        out = csv.writer(stream, lineterminator="\n")
        out.writerow(["setting"] + [f"{p}_{s}" for p in PRIORS for s in stats])
        for setting, endpoint in zip(SETTINGS, values[:, :, :, -1]):
            row = [setting]
            for column in endpoint:
                row.extend(format(v, ".17g") for v in (column.min(), np.median(column),
                                                         column.max(), np.ptp(column)))
            out.writerow(row)


def negative_label(x):
    return ("−" if x < 0 else "") + f"{abs(x):g}"


def main_ticks(lo, hi):
    # Coordinates are -log10(-ELBO/1000). Tick labels show untransformed levels.
    ticks = np.arange(np.ceil(lo), np.floor(hi) + 1, dtype=int)
    if len(ticks) >= 4:
        ticks = ticks[np.arange(len(ticks)) % 2 == (len(ticks) - 1) % 2]
    labels = []
    for tick in ticks:
        power = -int(tick)
        labels.append(r"$-10^{" + str(power) + "}$" if power >= 2 else negative_label(-10.**power))
    return ticks, labels


def new_axis(fig, rect):
    ax = fig.add_axes(rect)
    for spine in ax.spines.values():
        spine.set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_visible(True)
        ax.spines[side].set_color("#82908F")
        ax.spines[side].set_linewidth(.45)
    ax.tick_params(axis="both", length=2.2, width=.45, color="#82908F", pad=2)
    ax.set_axisbelow(True)
    return ax


def draw_figure(values, filename):
    """Draw ten trajectories per panel; share the ELBO scale within each setting."""
    matplotlib.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 7.2, "axes.unicode_minus": True,
        "text.color": "#222829", "xtick.color": "#303637", "ytick.color": "#303637",
        "mathtext.fontset": "dejavusans", "pdf.fonttype": 42, "ps.fonttype": 42,
        "path.simplify": False,
    })
    fig = plt.figure(figsize=SIZE, facecolor="white")
    n_starts = values.shape[2]
    cycles = np.arange(61)
    columns_left, columns_right = .193, .986
    col_gap = .026
    col_width = (columns_right - columns_left - 2 * col_gap) / 3
    top, bottom, row_gap = .950, .101, .0165
    row_height = (top - bottom - 8 * row_gap) / 9
    fig.text(.005, .976, "Setting", fontweight="bold", fontsize=9.2, va="center")
    fig.text(.113, (top + bottom) / 2, "Monitored ELBO (thousands; log spacing)",
             rotation=90, fontsize=8.3, ha="center", va="center")
    for j, prior in enumerate(PRIORS):
        x = columns_left + j * (col_width + col_gap)
        fig.text(x + col_width / 2, .976, prior + "-BNN", color="#1A343E",
                 fontweight="bold", fontsize=9.5, ha="center", va="center")
    levels = -np.log10(-values / 1000)
    for i, (setting, desc) in enumerate(zip(SETTINGS, DESIGNS)):
        y = top - (i + 1) * row_height - i * row_gap
        middle = y + row_height / 2
        desc_lines = desc.count("\n") + 1
        fig.text(.005, middle + .0045 + .0065 * desc_lines, setting,
                 va="center", fontsize=8.7, fontweight="bold")
        fig.text(.005, middle - .012, desc, va="center", linespacing=1.06, fontsize=6.9)
        row = levels[i]
        lo, hi = row.min(), row.max()
        pad = max((hi - lo) * .045, .015)
        ticks, labels = main_ticks(lo-pad, hi+pad)
        for j in range(3):
            x = columns_left + j * (col_width + col_gap)
            ax = new_axis(fig, [x, y, col_width, row_height])
            ax.set(xlim=(-.7, 60.7), ylim=(lo-pad, hi+pad))
            ax.set_yticks(ticks, labels if j == 0 else [])
            ax.set_xticks((0, 20, 40, 60), ("0", "20", "40", "60") if i == 8 else [])
            ax.tick_params(labelsize=6.4, axis="both")
            ax.grid(axis="y", color="#D8DFDE", linewidth=.46)
            for k in range(n_starts):
                ax.plot(cycles, row[j, k], color=COLOURS[k % 5], linestyle=STYLES[k // 5],
                        lw=.74, alpha=.91, solid_capstyle="round", dash_capstyle="butt")
    fig.text((columns_left + columns_right) / 2, .063, "Fitting cycle",
             ha="center", fontsize=7.7)
    handles = [Line2D([], [], color=COLOURS[k % 5], linestyle=STYLES[k // 5], lw=1.25)
               for k in range(n_starts)]
    fig.legend(handles, [str(k + 1) for k in range(n_starts)], ncol=n_starts, title=None,
               loc="center", bbox_to_anchor=(.535, .025), frameon=False, fontsize=7.3,
               handlelength=2, handletextpad=.35, columnspacing=1)
    fig.text(.220 if n_starts == 10 else .45, .025, "Start", ha="right", va="center", fontsize=7.6)
    fig.savefig(filename, format="pdf", metadata={"Title": "Monitored ELBO across initializations",
                "Creator": "Matplotlib", "Producer": "Matplotlib", "CreationDate": None,
                "ModDate": None})
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("traces", type=Path)
    parser.add_argument("figure", type=Path)
    parser.add_argument("summary", type=Path)
    # Retain this option for commands issued against earlier versions of the script.
    parser.add_argument("--curves-only", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    data = read_traces(args.traces)
    draw_figure(data, args.figure)
    write_summary(data, args.summary)
