"""Check the vector plot and nine-row summary against the 16,470 monitored ELBO values."""

import argparse
import csv
from collections import defaultdict
from itertools import product
from math import isfinite, log10
from pathlib import Path
from statistics import median

import fitz
import numpy as np


def read_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def common_linear_scale(source, points, description):
    x, y = np.asarray(source), np.asarray(points)
    if np.ptp(x) == 0:
        assert np.ptp(y) < .001, description
        return
    slope, shift = np.polyfit(x, y, deg=1)
    discrepancy = np.max(np.abs(y - (slope * x + shift)))
    assert slope > 0 and discrepancy < .001, (description, discrepancy)


def verify(traces, figure, summary, original=None):
    starts = range(1, 11)
    cycles = range(61)
    settings = [f"C{i}" for i in range(1, 10)]
    priors = ("G", "GL", "GLT")
    runs, provenance = defaultdict(dict), {}
    for row in read_csv(traces):
        key = (row["setting"], row["prior"], int(row["start"]))
        t, v = int(row["cycle"]), float(row["elbo"])
        assert t not in runs[key] and isfinite(v) and v < 0
        runs[key][t] = v
        if "init_sha" in row:
            info = (row["init_sha"], row["data_md5"], row["initial_seed"], row["vi_seed"])
            assert provenance.setdefault(key, info) == info
        if "mcse" in row:
            se = float(row["mcse"])
            assert isfinite(se) and se >= 0
    assert set(runs) == set(product(settings, priors, starts))
    assert all(set(row) == set(cycles) for row in runs.values())
    for s in settings:
        if provenance:
            for k in starts:
                assert len({provenance[s, p, k] for p in priors}) == 1
            assert len({provenance[s, "G", k][0] for k in starts}) == 10
            assert len({provenance[s, "G", k][1] for k in starts}) == 1
            assert len({provenance[s, "G", k][3] for k in starts}) == 1
    if original:
        baseline = read_csv(original)
        checked = set()
        for row in baseline:
            s, p = row["setting"], row["prior"]
            t = int(row["cycle"])
            assert (s, p, t) not in checked and int(row["start"]) == 1
            checked.add((s, p, t))
            assert runs[s, p, 1][t] == float(row["elbo"])
            if provenance:
                init, _, seed, vi = provenance[s, p, 1]
                assert (init, seed, vi) == (row["init_sha"], row["initial_seed"], row["vi_seed"])
        assert checked == set(product(settings, priors, cycles))

    summary_rows = read_csv(summary)
    assert [r["setting"] for r in summary_rows] == settings
    for s, row in zip(settings, summary_rows):
        for p in priors:
            ends = [runs[s,p,k][60] for k in starts]
            for label, expected in zip(("min","median","max","range"),
                                       (min(ends), median(ends), max(ends), max(ends)-min(ends))):
                assert float(row[f"{p}_{label}"]) == expected

    with fitz.open(figure) as doc:
        assert len(doc) == 1
        page = doc[0]
        text = page.get_text()
        assert all(f"{p}-BNN" in text for p in priors)
        assert all(s in text.split() for s in settings)
        assert "log spacing" in text
        assert text.count("Fitting cycle") == 1 and text.split().count("Start") == 1
        assert not {"End", "Trajectory", "shortfall"}.intersection(text.split())
        assert all(page.rect.contains(fitz.Rect(*word[:4])) for word in page.get_text("words"))
        assert not page.get_images()
        drawings = page.get_drawings()
        lines = [d["items"] for d in drawings if len(d["items"]) == 60
                 and all(t[0] == "l" for t in d["items"])]
        # This diagram consists entirely of straight line segments and axes.
        assert all(segment[0] != "c" for d in drawings for segment in d["items"])
        assert len(lines) == 270
        idx = 0
        for s in settings:
            raw, line_y = [], []
            previous_right = 0
            for p in priors:
                panel_x = None
                for k in starts:
                    segments = lines[idx]
                    points = [segments[0][1]] + [t[2] for t in segments]
                    x = np.array([pt.x for pt in points])
                    assert np.ptp(np.diff(x)) < .001
                    assert x[-1] - x[0] > .23 * page.rect.width
                    assert x[0] > previous_right
                    if panel_x is None:
                        panel_x = x
                    else:
                        assert np.max(np.abs(x - panel_x)) < .001
                    raw.extend(log10(-runs[s,p,k][t]) for t in cycles)
                    line_y.extend(pt.y for pt in points)
                    idx += 1
                previous_right = panel_x[-1]
            common_linear_scale(raw, line_y, s + " ELBO")
    print("Verified all 270 vector paths against 16,470 CSV records, and all nine summary rows.")
    print("Verified 27 wide trajectory panels, one shared cycle label, one start legend, and no endpoint markers.")
    if original:
        print("Verified exact reproduction of all 1,647 archived start-1 monitored values.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("traces", type=Path)
    parser.add_argument("figure", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("--original-start", type=Path, help="optional independent baseline CSV")
    args = parser.parse_args()
    verify(args.traces, args.figure, args.summary, args.original_start)
