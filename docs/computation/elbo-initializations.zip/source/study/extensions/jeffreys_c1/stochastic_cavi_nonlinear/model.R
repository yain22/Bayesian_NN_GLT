# Separate nonlinear diagnostic for the stochastic-preactivation CAVI candidate.
# The reference files are byte copies of the previously audited model/helpers.
sn_load <- function(extension_dir) {
  e <- new.env(parent=globalenv())
  q <- new.env(parent=asNamespace('stats'))
  sys.source(file.path(extension_dir,'reference','quadrature.R'),q)
  sys.source(file.path(extension_dir,'reference','model.R'),e)
  e$quad <- q
  e
}

sn_preprocess <- function(x,y) {
  x <- as.matrix(x);y <- as.numeric(y)
  stopifnot(nrow(x)==length(y),all(is.finite(x)),all(is.finite(y)))
  center <- colMeans(x);scale <- apply(x,2,sd)
  stopifnot(all(scale>0),sd(y)>0)
  list(x_center=center,x_scale=scale,y_center=mean(y),y_scale=sd(y))
}
sn_x <- function(x,p) {
  x <- as.matrix(x)
  stopifnot(ncol(x)==length(p$x_center),all(is.finite(x)))
  sweep(sweep(x,2,p$x_center,'-'),2,p$x_scale,'/')
}
sn_config <- function(x,y,delta2,control,e) {
  K <- c(4L,4L);d <- c(ncol(x)+1L,head(K,-1L)+1L)
  list(x=x,y=y,n=nrow(x),p=ncol(x),L=2L,K=K,d=d,c2=rep(1,length(d)),
    delta2=rep(delta2,2L),a0=0,b0=0,tol=control$quadrature_tol,quad=e$quad)
}
sn_control <- function()list(min_sweeps=50L,max_sweeps=300L,
  patience=10L,relative_tol=1e-7,quadrature_tol=1e-10,
  recheck_tol=1e-12,absolute_numerical_tol=1e-7,monitor='block')

# Prespecified training-only initialization, approved before any nonlinear fit.
# The original small prototype initializer remains unchanged in reference/.
sn_initialize <- function(seed,cfg,e) {
  s <- e$sc_initialize(seed,cfg)
  set.seed(seed)
  for(l in seq_len(cfg$L)) {
    features <- t(vapply(seq_len(cfg$n),function(i)
      e$sc_features(s,i,l-1L,cfg)$m,numeric(cfg$d[l])))
    width <- cfg$d[l]-1L
    for(k in seq_len(cfg$K[l])) {
      slopes <- rnorm(width,sd=sqrt(2/width))
      projection <- as.vector(features[,seq_len(width),drop=FALSE]%*%slopes)
      bias <- -runif(1L,min(projection),max(projection))
      s$w[[l]][[k]] <- e$sc_gaussian(c(slopes,bias),diag(.01,cfg$d[l]))
    }
    s$z[[l]] <- lapply(seq_len(cfg$n),function(i)lapply(seq_len(cfg$K[l]),function(k)
      e$sc_twopiece(1/cfg$delta2[l],
        sum(s$w[[l]][[k]]$mu*features[i,])/cfg$delta2[l],0,0)))
  }
  H <- t(vapply(seq_len(cfg$n),function(i)e$sc_features(s,i,cfg$L,cfg)$m,
    numeric(tail(cfg$K,1L)+1L)))
  output_mean <- solve(crossprod(H)+diag(1,ncol(H)),crossprod(H,cfg$y))
  s$v <- e$sc_gaussian(as.vector(output_mean),diag(.01,ncol(H)))
  s
}

sn_gaussian_kl <- function(old,new) {
  Q <- chol2inv(chol(new$Sigma));d <- new$mu-old$mu
  .5*(sum(Q*t(old$Sigma))+sum(d*(Q%*%d))-length(d)+new$logdet-old$logdet)
}
sn_latent_kl <- function(old,new) .5*(new$A-old$A)*old$second-
  (new$B-old$B)*old$mean+.5*(new$C-old$C)*old$relu_second-
  (new$D-old$D)*old$relu_mean+new$logZ-old$logZ
sn_ig_kl <- function(old,new)old$a*log(old$b)-lgamma(old$a)-
  new$a*log(new$b)+lgamma(new$a)+(new$a-old$a)*old$zeta+
  (new$b-old$b)*old$phi
sn_local_kl <- function(old,new)(new$A-old$A)*old$u+
  .5*(new$B-old$B)*old$phi+(new$d-old$d)*old$zeta+
  new$log_normalizer-old$log_normalizer
sn_tail_kl <- function(old,new)(new$C-old$C)*old$r+
  new$log_normalizer-old$log_normalizer

sn_fit <- function(x,y,delta2,seed,control=sn_control(),engine,
                   progress_file=NULL) {
  stopifnot(seed%in%c(101L,202L,303L),length(delta2)==1L,delta2>0,
    control$min_sweeps<=control$max_sweeps,
    control$monitor%in%c('block','coordinate'))
  started <- proc.time()[['elapsed']]
  prep <- sn_preprocess(x,y);xx <- sn_x(x,prep);yy <- (y-prep$y_center)/prep$y_scale
  cfg <- sn_config(xx,yy,delta2,control,engine);s <- sn_initialize(seed,cfg,engine)
  records <- list();coords <- list();sweeps <- list()
  initial <- engine$sc_elbo(s,cfg);current <- initial$value;index <- 0L;stable <- 0L
  records[[1L]] <- data.frame(sweep=0L,block='initial',coordinate=0L,
    elapsed_seconds=proc.time()[['elapsed']]-started,elbo=current,change=NA_real_,summed_coordinate_kl=NA_real_,
    gain_minus_kl=NA_real_,tight_rechecked=FALSE)
  block_start <- s;block_value <- current;block_gain <- 0;block_label <- ''
  block_coord <- 0L;block_sweep <- 0L;local_coords <- list()
  begin_block <- function(label,sweep) {
    block_start <<- s;block_value <<- current;block_gain <<- 0
    block_label <<- label;block_sweep <<- sweep;block_coord <<- 0L
  }
  record_direct <- function(label,gain,old_state,old_value) {
    z <- engine$sc_elbo(s,cfg);difference <- z$value-old_value;rechecked <- FALSE
    if(difference < -control$absolute_numerical_tol ||
       abs(difference-gain)>10*control$absolute_numerical_tol) {
      a <- engine$sc_refresh(old_state,cfg,control$recheck_tol)
      b <- engine$sc_refresh(s,cfg,control$recheck_tol)
      tighter <- engine$sc_elbo(b,cfg)$value-engine$sc_elbo(a,cfg)$value
      rechecked <- TRUE
      if(tighter < -control$absolute_numerical_tol ||
         abs(tighter-gain)>20*control$absolute_numerical_tol)
        stop(sprintf('Full ELBO/KL discrepancy at sweep %d %s: direct %.12g; KL %.12g; tight %.12g',
          block_sweep,label,difference,gain,tighter))
    }
    records[[length(records)+1L]] <<- data.frame(sweep=block_sweep,block=label,
      coordinate=index,elapsed_seconds=proc.time()[['elapsed']]-started,
      elbo=z$value,change=difference,summed_coordinate_kl=gain,
      gain_minus_kl=difference-gain,tight_rechecked=rechecked)
    current <<- z$value
  }
  apply_coordinate <- function(next_state,gain,type,l=NA_integer_,k=NA_integer_,i=NA_integer_) {
    if(!is.finite(gain) || gain < -control$absolute_numerical_tol)
      stop(sprintf('Negative/nonfinite coordinate KL: sweep %d %s %.12g',block_sweep,type,gain))
    before <- s;old_value <- current;s <<- next_state
    index <<- index+1L;block_coord <<- block_coord+1L;block_gain <<- block_gain+gain
    local_coords[[length(local_coords)+1L]] <<- data.frame(sweep=block_sweep,
      coordinate=index,block=block_label,type=type,layer=l,unit=k,row=i,kl_gain=gain)
    if(control$monitor=='coordinate')record_direct(paste0(block_label,':',type),gain,before,old_value)
  }
  end_block <- function() {
    if(control$monitor=='block')record_direct(block_label,block_gain,block_start,block_value)
  }
  for(iter in seq_len(control$max_sweeps)) {
    previous_sweep <- current;local_coords <- list()
    begin_block('hidden_weights',iter)
    for(l in seq_len(cfg$L))for(k in seq_len(cfg$K[l])) {
      old <- s$w[[l]][[k]];next_state <- engine$sc_weight_update(s,l,k,cfg)
      apply_coordinate(next_state,sn_gaussian_kl(old,next_state$w[[l]][[k]]),'weight',l,k)
    }
    end_block();begin_block('output_weights',iter)
    old <- s$v;next_state <- engine$sc_weight_update(s,cfg$L+1L,1L,cfg)
    apply_coordinate(next_state,sn_gaussian_kl(old,next_state$v),'output_weight');end_block()
    begin_block('output_hyperparameters',iter)
    for(type in c('u','rho')) {
      old <- s[[type]];next_state <- engine$sc_scale_update(s,type,cfg)
      apply_coordinate(next_state,sn_ig_kl(old,next_state[[type]]),type)
    }
    end_block();begin_block('observation_variance',iter)
    old <- s$noise;next_state <- engine$sc_scale_update(s,'noise',cfg)
    apply_coordinate(next_state,sn_ig_kl(old,next_state$noise),'noise');end_block()
    for(l in seq_len(cfg$L)) {
      begin_block(paste0('GLT_layer_',l),iter)
      for(k in seq_len(cfg$K[l])) {
        old <- s$g[[l]]$local[[k]];next_state <- engine$sc_scale_update(s,'local',cfg,l,k)
        apply_coordinate(next_state,sn_local_kl(old,next_state$g[[l]]$local[[k]]),'local',l,k)
      }
      old <- s$g[[l]]$tau;next_state <- engine$sc_scale_update(s,'tau',cfg,l)
      apply_coordinate(next_state,sn_ig_kl(old,next_state$g[[l]]$tau),'tau',l)
      for(k in seq_len(cfg$K[l])) {
        old <- s$g[[l]]$nu[[k]];next_state <- engine$sc_scale_update(s,'nu',cfg,l,k)
        apply_coordinate(next_state,sn_ig_kl(old,next_state$g[[l]]$nu[[k]]),'nu',l,k)
      }
      old <- s$g[[l]]$tail;next_state <- engine$sc_scale_update(s,'tail',cfg,l)
      apply_coordinate(next_state,sn_tail_kl(old,next_state$g[[l]]$tail),'tail',l);end_block()
    }
    for(l in seq_len(cfg$L)) {
      begin_block(paste0('latent_layer_',l),iter)
      for(i in seq_len(cfg$n))for(k in seq_len(cfg$K[l])) {
        old <- s$z[[l]][[i]][[k]];next_state <- engine$sc_latent_update(s,i,l,k,cfg)
        apply_coordinate(next_state,sn_latent_kl(old,next_state$z[[l]][[i]][[k]]),'latent',l,k,i)
      }
      end_block()
    }
    coords[[iter]] <- do.call(rbind,local_coords)
    relative_change <- abs(current-previous_sweep)/(1+abs(previous_sweep))
    stable <- if(iter>=control$min_sweeps && relative_change<=control$relative_tol)stable+1L else 0L
    sweeps[[iter]] <- data.frame(sweep=iter,elbo=current,change=current-previous_sweep,
      relative_change=relative_change,stable_sweeps=stable,
      elapsed_seconds=proc.time()[['elapsed']]-started)
    if(!is.null(progress_file) && (iter%%10L==0L || stable>=control$patience))
      cat(sprintf('%s sweep=%d ELBO=%.12f relative=%.5g elapsed=%.2f\n',
        format(Sys.time(),'%FT%T'),iter,current,relative_change,
        proc.time()[['elapsed']]-started),file=progress_file,append=TRUE)
    if(stable>=control$patience)break
  }
  cfg$quad <- NULL
  list(model='stochastic Gaussian preactivation with GLT hidden priors',
    status=if(stable>=control$patience)'relative_ELBO_stabilized' else 'max_sweeps',
    seed=seed,delta2=delta2,state=s,config=cfg,preprocess=prep,control=control,
    elapsed_seconds=proc.time()[['elapsed']]-started,
    block_trace=do.call(rbind,records),coordinate_trace=do.call(rbind,coords),
    sweep_trace=do.call(rbind,sweeps),final_components=engine$sc_elbo(s,cfg)$components)
}
