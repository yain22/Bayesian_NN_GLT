cb_forward<-function(x,W,rate=0) {
 h<-x;features<-pre<-masks<-list()
 for(l in seq_along(W)) {
  features[[l]]<-cbind(h,1);z<-features[[l]]%*%t(W[[l]]);pre[[l]]<-z
  if(l<length(W)) {
   h<-pmax(z,0);mask<-matrix(1,nrow(h),ncol(h))
   if(rate>0)mask<-matrix(rbinom(length(h),1,1-rate)/(1-rate),nrow(h))
   masks[[l]]<-mask;h<-h*mask
  } else h<-z
 }
 list(y=as.vector(h),features=features,pre=pre,masks=masks)
}
cb_train<-function(x,y,K,seed,steps=600L,rate=0,l1=0,W=NULL) {
 set.seed(seed)
 if(is.null(W)) {
  dims<-c(ncol(x),K);outs<-c(K,1L)
  W<-lapply(seq_along(outs),function(l)matrix(rnorm(outs[l]*(dims[l]+1),sd=sqrt(2/(dims[l]+1))),outs[l]))
 }
 m<-v<-lapply(W,function(w)w*0)
 for(t in seq_len(steps)) {
  f<-cb_forward(x,W,rate);back<-matrix((f$y-y)/length(y),ncol=1);grad<-list()
  for(l in rev(seq_along(W))) {
   grad[[l]]<-crossprod(back,f$features[[l]])+l1*sign(W[[l]])
   if(l>1)back<-(back%*%W[[l]][,-ncol(W[[l]]),drop=FALSE])*(f$pre[[l-1]]>0)*f$masks[[l-1]]
  }
  for(l in seq_along(W)) {
   m[[l]]<-.9*m[[l]]+.1*grad[[l]];v[[l]]<-.999*v[[l]]+.001*grad[[l]]^2
   W[[l]]<-W[[l]]-.003*(m[[l]]/(1-.9^t))/(sqrt(v[[l]]/(1-.999^t))+1e-8)
  }
 }
 W
}
cb_predict<-function(fit,x,draws=256L,seed=1L) {
 # Integrates weight uncertainty and hidden noise by independent predictive draws.
 # Each conditional mean is Rao-Blackwellized over the final-layer noise.
 set.seed(seed);xx<-sn_x(x,fit$preprocess);s<-fit$state;L<-fit$config$L
 cholW<-lapply(s$w,function(layer)lapply(layer,function(w)chol(w$Sigma)));cv<-chol(s$v$Sigma)
 pred<-matrix(0,draws,nrow(xx))
 for(b in seq_len(draws)) {
  h<-xx
  for(l in seq_len(L)) {
   W<-do.call(rbind,lapply(seq_along(s$w[[l]]),function(k)s$w[[l]][[k]]$mu+as.vector(rnorm(length(s$w[[l]][[k]]$mu))%*%cholW[[l]][[k]])))
   mu<-cbind(h,1)%*%t(W)
   h<-if(l<L)pmax(mu+matrix(rnorm(length(mu),sd=sqrt(.005)),nrow(mu)),0)else sn_rectified_normal(mu,sqrt(.005))
  }
  v<-s$v$mu+as.vector(rnorm(length(s$v$mu))%*%cv)
  pred[b,]<-as.vector(cbind(h,1)%*%v)*fit$preprocess$y_scale+fit$preprocess$y_center
 }
 list(mean=colMeans(pred),mcse=apply(pred,2,sd)/sqrt(draws),draws=pred)
}
