# Crossed low-SNR extension. Source from the R project and call snr1_main().
# Fits share the original predictors and standardized errors across SNR levels.
# The original C9 archive supplies the low-SNR reference additive condition.

snr1_architectures <- list(d2w25=rep(25L,2L),d2w50=rep(50L,2L),
                           d5w25=rep(25L,5L),d5w50=rep(50L,5L))
snr1_methods <- c("g","hs","glt","fnn","dropout","l1")
snr1_cells <- c(1L,3L,4L,5L,6L,7L,8L)
snr1_control <- list(outer=60L,weight_steps=10L,lr=.003,weight_draws=4L,
                      noise_draws=16L,monitor_draws=64L,endpoint_draws=256L)
snr1_engines <- c(
  "extensions/relu_arch/run.R"="ee3c12314440a81f3755a842e253f6db",
  "extensions/relu100/engine.R"="8b54d41a67cc4a5419d8cd9e27ce38c8",
  "extensions/cavi_benchmark/priors.R"="fde5222aeec7a5ea555797e139979d12",
  "extensions/cavi_benchmark/network.R"="6eec7899d52e6c6b54bf26fac3d693d5",
  "extensions/jeffreys_c1/stochastic_cavi_nonlinear/model.R"="0ec01b1a8f690cfbadba78fbc5a8ca10",
  "extensions/jeffreys_c1/stochastic_cavi_nonlinear/reference/model.R"="75552bba7cccb6719f1e1fe3511097d2",
  "extensions/jeffreys_c1/stochastic_cavi_nonlinear/reference/quadrature.R"="f7051184866143eda5d25dc0ec51b4db",
  "R/study_utils.R"="ce0f5eb0acdb2b9dd79c40307f005f18")

snr1_host <- function(expected) {
  short <- function(x)tolower(sub("[.].*$","",x))
  if(length(expected)!=1L || is.na(expected) || !nzchar(expected) ||
     short(unname(Sys.info()[["nodename"]]))!=short(expected))
    stop("The designated simulation computer could not be verified.",call.=FALSE)
}

snr1_id <- function(cell,replicate)sprintf("c%d_r%03d",cell,replicate)

snr1_atomic <- function(value,path,csv=FALSE) {
  tmp <- tempfile(".pending-",tmpdir=dirname(path))
  on.exit(unlink(tmp),add=TRUE)
  if(csv)write.csv(value,tmp,row.names=FALSE)else saveRDS(value,tmp,version=3)
  if(file.exists(path)||!file.rename(tmp,path))stop("Checkpoint commit failed for ",basename(path))
}

snr1_rds <- function(path,make) {
  if(!file.exists(path))snr1_atomic(make(),path)
  readRDS(path)
}

snr1_load <- function(root) {
  actual <- unname(tools::md5sum(file.path(root,names(snr1_engines))))
  if(!identical(actual,unname(snr1_engines)))stop("Fitting or generator source differs from the archived benchmark.")
  sys.source(file.path(root,"extensions/relu_arch/run.R"),envir=.GlobalEnv)
  relu_arch_load(root)
}

# Train and test errors come from the original generator with the original cell
# and split seeds. Only their standard deviation changes, from 1/sqrt(3) to 1.
snr1_prepare <- function(job,out) {
  cell <- .snr1_settings[.snr1_settings$id==job$cell,,drop=FALSE]
  path <- file.path(out,"data",paste0(snr1_id(job$cell,job$replicate),".rds"))
  if(!file.exists(path)) {
    d <- tabnn_simulate(cell,"gaussian",job$replicate,phase="cavi100_v1",
                        n_test=2000L,n_cal=0L,reference=.snr1_references[[as.character(job$cell)]],snr=1)
    stopifnot(d$generation$snr==1,nrow(d$train$x)==cell$n,nrow(d$test$x)==2000L)
    snr1_atomic(d,path)
  }
  unname(tools::md5sum(path))
}

snr1_fit_method <- function(m,d,W,pre,x,y,K,initial,vi,predict_seed) {
  if(m%in%c("g","hs","glt")) {
    fit <- relu_fit(d$train$x,d$train$y,W,m,relu_arch_reference,seed=vi,control=snr1_control)
    stopifnot(identical(fit$status,"fixed_budget"),fit$outer==60L,
      nrow(fit$weight_steps)==600L,identical(fit$config$K,K),all(is.finite(fit$trace$elbo)),
      is.finite(fit$endpoint$value),all(fit$config$c2==1),fit$config$a0==0,fit$config$b0==0)
    pred <- relu_predict(fit,d$test$x,draws=256L,seed=predict_seed)
    prediction <- pred$mean
    fit <- relu_arch_pack(fit)
    # Training matrices are saved once per dataset and can be reconstructed
    # from its train split and the retained preprocessing parameters.
    fit$config$x <- fit$config$y <- NULL
  } else {
    weights <- cb_train(x,y,K,tabnn_seed(initial,m),600L,
      rate=if(m=="dropout").2 else 0,l1=if(m=="l1").001 else 0,W=W)
    relu_arch_dimensions(weights,ncol(x),K)
    prediction <- cb_forward(sn_x(d$test$x,pre),weights)$y*pre$y_scale+pre$y_center
    fit <- list(weights=weights,preprocess=pre,method_seed=tabnn_seed(initial,m),steps=600L)
  }
  stopifnot(length(prediction)==length(d$test$y),all(is.finite(prediction)))
  list(fit=fit,prediction=prediction)
}

snr1_job <- function(job,out) {
  id <- snr1_id(job$cell,job$replicate)
  folder <- file.path(out,job$architecture,id)
  dir.create(folder,recursive=TRUE,showWarnings=FALSE)
  data_path <- file.path(out,"data",paste0(id,".rds"))
  stopifnot(identical(unname(tools::md5sum(data_path)),job$data_md5))
  d <- readRDS(data_path);K <- snr1_architectures[[job$architecture]]
  stopifnot(d$cell$id==job$cell,d$replicate==job$replicate,d$cell$snr==1,
            d$generation$snr==1,d$phase=="cavi100_v1",d$family=="gaussian")
  pre <- sn_preprocess(d$train$x,d$train$y); x <- sn_x(d$train$x,pre)
  y <- (d$train$y-pre$y_center)/pre$y_scale
  initial <- tabnn_seed("cavi100_v1",job$cell,job$replicate,"initial")
  vi <- tabnn_seed("relu100_v1",job$cell,job$replicate,"variational")
  predict_seed <- tabnn_seed(initial,"predict")
  init_path <- file.path(folder,"initializer.rds")
  init <- snr1_rds(init_path,function()list(weights=cb_train(x,y,K,initial,600L),
    data_md5=job$data_md5,seed=initial))
  stopifnot(identical(init$data_md5,job$data_md5),init$seed==initial)
  relu_arch_dimensions(init$weights,ncol(x),K)
  init_hash <- unname(tools::md5sum(init_path))
  rows <- lapply(snr1_methods,function(m) {
    rowpath <- file.path(folder,paste0(m,"_result.rds"))
    fitpath <- file.path(folder,paste0(m,"_fit.rds"))
    # A single atomic fit commit contains its score and predictions. If the
    # controller stopped before the small score file was written, recover it.
    if(file.exists(rowpath)) {
      stopifnot(file.exists(fitpath))
      row <- readRDS(rowpath)
    } else {
      bundle <- snr1_rds(fitpath,function() {
        started <- proc.time()[3]
        result <- snr1_fit_method(m,d,init$weights,pre,x,y,K,initial,vi,predict_seed)
        row <- data.frame(architecture=job$architecture,depth=length(K),width=K[1L],
          cell=job$cell,snr=1,replicate=job$replicate,method=m,status="fixed_budget",
          rmse=sqrt(mean((result$prediction-d$test$y)^2)),
          mean_rmse=sqrt(mean((result$prediction-d$test$truth)^2)),
          data_md5=job$data_md5,initializer_md5=init_hash,initial_seed=initial,
          variational_seed=vi,prediction_seed=predict_seed,seconds=unname(proc.time()[3]-started))
        stopifnot(is.finite(row$rmse),is.finite(row$mean_rmse))
        c(result,list(row=row))
      })
      row <- bundle$row
      snr1_atomic(row,rowpath)
    }
    stopifnot(nrow(row)==1L,row$method==m,row$cell==job$cell,row$replicate==job$replicate,
      row$architecture==job$architecture,row$snr==1,row$status=="fixed_budget",
      row$data_md5==job$data_md5,row$initializer_md5==init_hash,is.finite(row$rmse))
    row
  })
  do.call(rbind,rows)
}

snr1_main <- function(root=getwd(),workers=20L,expected_host=Sys.getenv("BNN_EXPECTED_SIM_HOST")) {
  snr1_host(expected_host)
  stopifnot(length(workers)==1L,is.finite(workers),workers==as.integer(workers),
    workers>=1L,workers<=parallel::detectCores(logical=TRUE),workers<=20L)
  root <- normalizePath(root,winslash="/",mustWork=TRUE)
  out <- file.path(root,"outputs/continuous_v2/simulation/relu_snr1_v1")
  dir.create(file.path(out,"data"),recursive=TRUE,showWarnings=FALSE)
  # An OS-held local socket lock is released automatically if the process dies.
  # Every controller for this experiment, including a restart, uses this port.
  lock <- tryCatch(serverSocket(39471L),error=function(e)stop("The run lock is in use.",call.=FALSE))
  on.exit(close(lock),add=TRUE)
  snr1_load(root)
  complete <- file.path(out,"complete.rds"); scores <- file.path(out,"results.csv")
  if(file.exists(complete)) {
    stopifnot(identical(readRDS(complete),unname(tools::md5sum(scores))))
    return(invisible(out))
  }
  settings <- relu_arch_settings()
  settings <- settings[settings$id%in%snr1_cells,,drop=FALSE];settings$snr <- 1
  protocol <- list(version="reference_variance_snr1_v1",settings=settings,
                   replicate=1:100,architectures=snr1_architectures,methods=snr1_methods,
                   control=snr1_control,engines=snr1_engines)
  stopifnot(identical(protocol,snr1_rds(file.path(out,"protocol.rds"),function()protocol)))
  Sys.setenv(OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",
             BLIS_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1")
  references <- setNames(lapply(seq_len(nrow(settings)),function(i) {
    ref <- tabnn_reference(settings[i,,drop=FALSE])
    ref[c("center","scale","seed","n")]
  }),as.character(settings$id))
  cl <- parallel::makePSOCKcluster(as.integer(workers))
  on.exit(parallel::stopCluster(cl),add=TRUE,after=FALSE)
  parallel::clusterCall(cl,function(root,expected,settings,references) {
    sys.source(file.path(root,"extensions/relu_snr1_v1/run.R"),.GlobalEnv)
    snr1_host(expected);snr1_load(root)
    assign(".snr1_settings",settings,.GlobalEnv);assign(".snr1_references",references,.GlobalEnv)
    TRUE
  },root,expected_host,settings,references)
  grid <- expand.grid(cell=snr1_cells,replicate=1:100)
  jobs <- lapply(seq_len(nrow(grid)),function(i)as.list(grid[i,,drop=FALSE]))
  hashes <- unlist(parallel::parLapplyLB(cl,jobs,snr1_prepare,out=out,chunk.size=1L),use.names=FALSE)
  stopifnot(length(hashes)==700L,!anyNA(hashes))
  grid$data_md5 <- hashes
  stopifnot(identical(grid,snr1_rds(file.path(out,"datasets.rds"),function()grid)))
  grid <- merge(grid,data.frame(architecture=names(snr1_architectures)),by=NULL,sort=FALSE)
  # Feed expensive settings first to avoid a long final batch on a single worker.
  grid <- grid[order(grid$architecture=="d5w50" & grid$cell==6L,decreasing=TRUE),]
  jobs <- lapply(seq_len(nrow(grid)),function(i)as.list(grid[i,,drop=FALSE]))
  retry_job <- function(job,out) {
    tryCatch(snr1_job(job,out),error=function(first) {
      Sys.sleep(2)
      tryCatch(snr1_job(job,out),error=function(second)
        stop(sprintf("%s C%d replication %d: %s",job$architecture,job$cell,job$replicate,
                     conditionMessage(second)),call.=FALSE))
    })
  }
  environment(retry_job) <- .GlobalEnv
  rows <- parallel::parLapplyLB(cl,jobs,retry_job,out=out,chunk.size=1L)
  records <- do.call(rbind,rows)
  records <- records[order(records$architecture,records$cell,records$replicate,records$method),]
  rownames(records) <- NULL
  key <- c("architecture","cell","replicate","method")
  stopifnot(nrow(records)==16800L,!anyDuplicated(records[key]),all(records$status=="fixed_budget"),
            all(is.finite(records$rmse)),all(table(records$architecture,records$cell,records$method)==100L))
  if(file.exists(scores)) {
    previous <- read.csv(scores)
    stopifnot(isTRUE(all.equal(records,previous,tolerance=1e-12,check.attributes=FALSE)))
  } else snr1_atomic(records,scores,csv=TRUE)
  snr1_atomic(unname(tools::md5sum(scores)),complete)
  invisible(out)
}

