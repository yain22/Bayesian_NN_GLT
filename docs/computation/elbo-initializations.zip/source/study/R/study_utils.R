# Reproducible data, preprocessing, metrics, and fit/predict adapters.
# These functions never use test outcomes for fitting or tuning.

tabnn_seed <- function(...) {
  h <- 20261030
  for (b in utf8ToInt(paste(..., collapse = "|"))) h <- (131*h+b) %% 2147483646
  as.integer(h+1)
}
tabnn_ar1 <- function(n, p, rho) {
  x <- matrix(rnorm(n*p), n, p)
  if (p > 1L) for (j in 2:p) x[,j] <- rho*x[,j-1L]+sqrt(1-rho^2)*x[,j]
  colnames(x) <- paste0("x",seq_len(p)); x
}
tabnn_signal <- function(x, kind, s) {
  z <- x[,seq_len(s),drop=FALSE]
  switch(kind,
    linear=as.vector(z %*% rep(c(1,-1),length.out=s))/sqrt(s),
    additive=rowSums(sin(z)+.5*(z^2-1))/sqrt(s),
    interaction={
      stopifnot(s %% 2L == 0L)
      rowSums(sin(z[,seq(1,s,2),drop=FALSE])*z[,seq(2,s,2),drop=FALSE])/sqrt(s/2)
    },stop("Unknown signal: ",kind))
}
tabnn_reference <- function(cell, n=100000L) {
  seed <- tabnn_seed("reference",cell$signal,cell$s,cell$rho,n)
  set.seed(seed)
  raw <- tabnn_signal(tabnn_ar1(n,cell$s,cell$rho),cell$signal,cell$s)
  list(center=mean(raw),scale=sd(raw),g=(raw-mean(raw))/sd(raw),seed=seed,n=n)
}
tabnn_simulate <- function(cell,family,replicate,phase="main",
                           n_test=2000L,n_cal=500L,reference=NULL,
                           snr=3,prevalence=.5,amplitude=2) {
  if (is.null(reference)) reference <- tabnn_reference(cell)
  intercept <- if(family=="binomial") uniroot(
    function(b)mean(plogis(b+amplitude*reference$g))-prevalence,
    c(-40,40),tol=1e-12)$root else NA_real_
  generate <- function(n,split) {
    set.seed(tabnn_seed(phase,cell$id,replicate,family,split))
    x <- tabnn_ar1(n,cell$p,cell$rho)
    g <- (tabnn_signal(x,cell$signal,cell$s)-reference$center)/reference$scale
    if(family=="gaussian") {
      y <- g+rnorm(n,sd=1/sqrt(snr)); truth <- g
    } else {
      truth <- plogis(intercept+amplitude*g); y <- rbinom(n,1,truth)
    }
    list(x=x,y=y,truth=truth)
  }
  list(train=generate(cell$n,"train"),test=generate(n_test,"test"),
       calibration=if(family=="gaussian"&&n_cal>0)generate(n_cal,"calibration")else NULL,
       family=family,cell=cell,replicate=replicate,phase=phase,
       reference=reference[c("center","scale","seed","n")],
       generation=list(snr=snr,prevalence=prevalence,amplitude=amplitude,intercept=intercept))
}
tabnn_preprocess_fit <- function(x,y,family) {
  x <- as.matrix(x)
  x <- matrix(as.numeric(x),nrow(x),ncol(x),dimnames=dimnames(x))
  if(any(is.infinite(x))||any(!is.finite(y)))stop("Nonfinite input/outcome.")
  impute <- vapply(seq_len(ncol(x)),function(j) {
    v <- x[,j]; if(all(is.na(v)))0 else median(v,na.rm=TRUE)
  },numeric(1))
  for(j in seq_len(ncol(x)))x[is.na(x[,j]),j] <- impute[j]
  center <- colMeans(x)
  scale <- apply(x,2,sd)
  keep <- which(is.finite(scale)&scale>1e-12)
  if(!length(keep))stop("No varying predictor in fitting partition.")
  ys <- if(family=="gaussian")sd(y)else 1
  ym <- if(family=="gaussian")mean(y)else 0
  if(!is.finite(ys)||ys<1e-12)stop("Degenerate training outcome.")
  structure(list(impute=impute,center=center,scale=scale,keep=keep,
                 y_center=ym,y_scale=ys,original_p=ncol(x),
                 family=family),class="tabnn_preprocess")
}
tabnn_preprocess_x <- function(pre,x) {
  x <- as.matrix(x)
  x <- matrix(as.numeric(x),nrow(x),ncol(x),dimnames=dimnames(x))
  stopifnot(ncol(x)==pre$original_p)
  if(any(is.infinite(x)))stop("Infinite predictor.")
  for(j in seq_len(ncol(x)))x[is.na(x[,j]),j] <- pre$impute[j]
  x <- sweep(sweep(x[,pre$keep,drop=FALSE],2,pre$center[pre$keep],"-"),
             2,pre$scale[pre$keep],"/")
  colnames(x)<-paste0("x",pre$keep); x
}
tabnn_restore_prediction <- function(pred,pre) {
  if(pre$family=="gaussian") {
    pred$mean <- pred$mean*pre$y_scale+pre$y_center
    for(nm in c("latent_draws","response_draws"))
      if(!is.null(pred[[nm]]))pred[[nm]]<-pred[[nm]]*pre$y_scale+pre$y_center
    if(!is.null(pred$noise_draws))pred$noise_draws<-pred$noise_draws*pre$y_scale
  }
  pred
}
tabnn_folds <- function(y,k=3L,seed=1L,stratified=FALSE) {
  set.seed(seed); n<-length(y)
  if(k<2L||k>n)stop("Invalid fold count.")
  fold<-integer(n)
  strata<-if(stratified)split(seq_len(n),y)else list(seq_len(n))
  if(stratified&&any(lengths(strata)<k))stop("Too few members of a class for folds.")
  for(ii in strata)fold[ii[sample.int(length(ii))]]<-rep(seq_len(k),length.out=length(ii))
  fold
}
tabnn_holdout <- function(y,fraction=.2,seed=1L,stratified=FALSE) {
  set.seed(seed)
  strata<-if(stratified)split(seq_along(y),y)else list(seq_along(y))
  if(!is.finite(fraction)||fraction<=0||fraction>=1)stop("Invalid holdout fraction")
  if(any(lengths(strata)<2L))stop("Holdout requires at least two observations per stratum")
  sort(unlist(lapply(strata,function(ii) {
    size<-max(1L,min(length(ii)-1L,floor(length(ii)*fraction)))
    ii[sample.int(length(ii),size)]
  })))
}
tabnn_auc <- function(y,p) {
  n1<-sum(y==1);n0<-sum(y==0)
  if(n1==0L||n0==0L)return(NA_real_)
  (sum(rank(p,ties.method="average")[y==1])-n1*(n1+1)/2)/(n1*n0)
}
tabnn_average_precision <- function(y,p) {
  if(!sum(y==1))return(NA_real_)
  o<-order(p,decreasing=TRUE); y<-y[o];p<-p[o]
  ends<-c(which(diff(p)!=0),length(p))
  tp<-cumsum(y)[ends];precision<-tp/ends
  sum(diff(c(0,tp))/sum(y)*precision)
}
tabnn_col_logmeanexp <- function(z) {
  apply(z,2,function(v){a<-max(v);if(!is.finite(a))a else a+log(mean(exp(v-a)))})
}
tabnn_metrics <- function(y,pred,family,truth=NULL,calibration=NULL,alpha=.1) {
  if(is.null(pred$mean)||length(pred$mean)!=length(y)||any(!is.finite(pred$mean)))
    stop("Invalid prediction means.")
  out<-list()
  pointwise<-list()
  interval<-NULL
  if(family=="gaussian") {
    out$rmse<-sqrt(mean((pred$mean-y)^2))
    out$mae<-mean(abs(pred$mean-y))
    out$truth_rmse<-if(!is.null(truth))sqrt(mean((pred$mean-truth)^2))else NA_real_
    out$nll<-out$native_coverage<-out$native_width<-NA_real_
    if(!is.null(pred$latent_draws)&&!is.null(pred$noise_draws)) {
      latent<-as.matrix(pred$latent_draws);noise<-as.numeric(pred$noise_draws)
      stopifnot(ncol(latent)==length(y),nrow(latent)==length(noise),all(noise>0))
      logd<-matrix(dnorm(rep(y,each=nrow(latent)),as.vector(latent),
                         rep(noise,length(y)),log=TRUE),nrow(latent))
      pointwise$log_density<-tabnn_col_logmeanexp(logd)
      out$nll<--mean(pointwise$log_density)
    }
    if(!is.null(pred$response_draws)) {
      q<-apply(as.matrix(pred$response_draws),2,quantile,
               probs=c(alpha/2,1-alpha/2),names=FALSE)
      interval<-list(lower=q[1,],upper=q[2,])
      out$native_coverage<-mean(y>=q[1,]&y<=q[2,])
      out$native_width<-mean(q[2,]-q[1,])
    }
    out$conformal_coverage<-out$conformal_width<-NA_real_
    if(!is.null(calibration)) {
      residuals<-abs(calibration$y-calibration$mean)
      m<-length(residuals);k<-ceiling((m+1)*(1-alpha))
      radius<-if(k>m)Inf else sort(residuals)[k]
      out$conformal_coverage<-mean(abs(y-pred$mean)<=radius)
      out$conformal_width<-2*radius
      pointwise$conformal_radius<-radius
    }
  } else {
    if(any(pred$mean<0|pred$mean>1))stop("Probability outside [0,1].")
    p<-pmin(pmax(pred$mean,1e-12),1-1e-12)
    pointwise$log_density<-ifelse(y==1,log(p),log1p(-p))
    out$log_loss<--mean(pointwise$log_density)
    out$brier<-mean((pred$mean-y)^2)
    out$auc<-tabnn_auc(y,pred$mean)
    out$average_precision<-tabnn_average_precision(y,pred$mean)
    out$accuracy<-mean((pred$mean>=.5)==y)
    out$clipped_probabilities<-sum(p!=pred$mean)
    out$truth_rmse<-if(!is.null(truth))sqrt(mean((pred$mean-truth)^2))else NA_real_
    out$probability_coverage<-out$probability_width<-NA_real_
    if(!is.null(pred$probability_draws)) {
      q<-apply(as.matrix(pred$probability_draws),2,quantile,
               probs=c(alpha/2,1-alpha/2),names=FALSE)
      interval<-list(lower=q[1,],upper=q[2,])
      out$probability_width<-mean(q[2,]-q[1,])
      if(!is.null(truth))out$probability_coverage<-mean(truth>=q[1,]&truth<=q[2,])
    }
  }
  list(metrics=out,pointwise=pointwise,interval=interval)
}
tabnn_model_kind <- function(method) {
  switch(method,glt="glt",fixed_glt="glt",horseshoe_bnn="hs",
         regularized_horseshoe_bnn="rhs",frequentist_nn="frequentist",NA_character_)
}
tabnn_fit_one <- function(method,x,y,family,control=list(),seed=1L,
                           hidden=c(25L,25L)) {
  if(!is.null(control$.hidden)) {
    hidden<-as.integer(control$.hidden)
    control$.hidden<-NULL
  }
  pre<-tabnn_preprocess_fit(x,y,family)
  xx<-tabnn_preprocess_x(pre,x);yy<-(y-pre$y_center)/pre$y_scale
  if(!is.null(control$.mtry_fraction)) {
    control$mtry<-max(1L,min(ncol(xx),as.integer(round(control$.mtry_fraction*ncol(xx)))))
    control$.mtry_fraction<-NULL
  }
  kind<-tabnn_model_kind(method)
  started<-proc.time()[[3]]
  warnings<-character()
  fit<-tryCatch(withCallingHandlers({
    if(!is.na(kind)) {
      if(method=="fixed_glt")control$xi_fixed<-1
      tabnn_fit(xx,yy,family=family,hidden=hidden,prior=kind,control=control,seed=seed)
    } else tabnn_fit_competitor(method,xx,yy,family=family,control=control,seed=seed)
  },warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")}),
    error=function(e)list(status="failed",reason=conditionMessage(e)))
  if(is.null(fit$status))fit$status<-"ok"
  list(status=fit$status,model=fit,preprocess=pre,method=method,family=family,
       seconds=proc.time()[[3]]-started,warnings=unique(warnings),seed=seed,
       hidden=hidden,control=control)
}
tabnn_predict_one <- function(fitted,x,draws=200L,seed=1L) {
  if(fitted$status!="ok")stop("Cannot predict a non-ok fit.")
  xx<-tabnn_preprocess_x(fitted$preprocess,x)
  kind<-tabnn_model_kind(fitted$method)
  pred<-if(!is.na(kind))tabnn_predict(fitted$model,xx,draws=draws,seed=seed)else
    tabnn_predict_competitor(fitted$model,xx,draws=draws,seed=seed)
  tabnn_restore_prediction(pred,fitted$preprocess)
}
tabnn_subset_prediction <- function(pred,index) {
  ans<-pred;ans$mean<-pred$mean[index]
  for(nm in c("latent_draws","probability_draws","response_draws"))
    if(!is.null(pred[[nm]]))ans[[nm]]<-pred[[nm]][,index,drop=FALSE]
  ans
}
tabnn_select_control <- function(method,x,y,family,candidates,folds,seed,
                                  hidden=c(25L,25L),draws=50L) {
  if(length(candidates)==1L)return(list(control=candidates[[1L]],index=1L,
                                       scores=NA_real_,fits=0L))
  if(is.null(folds))stop("Multiple candidates require validation folds.")
  levels<-sort(unique(folds[folds>0]))
  scores<-matrix(NA_real_,length(candidates),length(levels))
  diagnostics<-list()
  for(c in seq_along(candidates))for(j in seq_along(levels)) {
    valid<-which(folds==levels[j]);train<-setdiff(seq_len(nrow(x)),valid)
    # Folds coded zero support a predefined single holdout.
    f<-tabnn_fit_one(method,x[train,,drop=FALSE],y[train],family,candidates[[c]],
                     tabnn_seed(seed,"tune",c,j),hidden)
    if(f$status=="ok") {
      p<-tryCatch(tabnn_predict_one(f,x[valid,,drop=FALSE],draws,
                                    tabnn_seed(seed,"tune-pred",c,j)),
                  error=function(e)NULL)
      if(!is.null(p))scores[c,j]<-if(family=="gaussian")mean((p$mean-y[valid])^2)else
        -mean(ifelse(y[valid]==1,log(pmax(p$mean,1e-12)),
                      log(pmax(1-p$mean,1e-12))))
    }
    diagnostics[[paste(c,j,sep="_")]]<-list(status=f$status,seconds=f$seconds,
                                           warnings=f$warnings,reason=f$model$reason)
  }
  complete<-rowSums(is.finite(scores))==ncol(scores)
  averages<-rowMeans(scores);averages[!complete]<-Inf
  if(!any(complete))stop("All hyperparameter candidates failed validation.")
  chosen<-which.min(averages)
  list(control=candidates[[chosen]],index=chosen,scores=scores,
       diagnostics=diagnostics,fits=length(scores))
}
tabnn_atomic_save <- function(object,path) {
  dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
  temporary<-paste0(path,".tmp-",Sys.getpid())
  saveRDS(object,temporary,version=3)
  if(!file.rename(temporary,path))stop("Could not atomically save ",path)
  invisible(path)
}
