# Private numerical instrumentation. Delegates the calculation to the unmodified
# installed study function and observes each returned learned-tail factor.
observe_tail_engine <- function(engine) {
  fit_function <- engine$.gltbnn_engine_fit
  tail_function <- engine$.bnn_coefficient_tail
  visits <- list()
  engine$.bnn_coefficient_tail <- function(count, C, fixed_shape) {
    factor <- tail_function(count, C, fixed_shape)
    if (is.null(fixed_shape)) {
      stopifnot(length(factor$r)==1L, is.finite(factor$r), factor$r>0, factor$r<=2,
                identical(factor$C,C), count==factor$K,
                all(is.finite(c(C,factor$eta_mean,factor$log_normalizer,factor$entropy_eta))))
      visits[[length(visits)+1L]] <<- c(M=count,C=C,r=factor$r)
    }
    factor
  }
  attach_extrema <- function(fit) {
    if (fit$config$prior!="GLT" || !is.null(fit$config$fixed_shape)) {
      stopifnot(length(visits)==0L)
      return(fit)
    }
    d <- do.call(rbind,visits)
    counts <- fit$config$M
    cycles <- fit$outer+1L
    stopifnot(nrow(d)==cycles*length(counts),all(d[,"M"]==rep(counts,cycles)))
    fit$tail_audit <- do.call(rbind,lapply(seq_along(counts),function(l) {
      z <- d[seq.int(l,nrow(d),by=length(counts)),,drop=FALSE]
      i <- nrow(z)
      stopifnot(z[i,"r"]==fit$state$g[[l]]$tail$r,z[i,"C"]==fit$state$g[[l]]$tail$C)
      data.frame(layer=l,M=counts[l],calls=i,C_min=min(z[,"C"]),C_max=max(z[,"C"]),
                 r_min=min(z[,"r"]),r_max=max(z[,"r"]),C_at_r_min=z[which.min(z[,"r"]),"C"],
                 C_at_r_max=z[which.max(z[,"r"]),"C"],final_C=z[i,"C"],final_r=z[i,"r"],
                 row.names=NULL)
    }))
    fit
  }
  engine$.gltbnn_engine_fit <- function(...,on_milestone=NULL) {
    visits <<- list()
    callback <- if(is.function(on_milestone)) function(outer,fit) on_milestone(outer,attach_extrema(fit))
    attach_extrema(fit_function(...,on_milestone=callback))
  }
  engine
}

check_tail_oracle <- function(engine, reference) {
  o <- read.csv(reference,header=FALSE,col.names=c("M","C","r","eta","logZ","entropy"))
  stopifnot(nrow(o)>=6L)
  for (i in seq_len(nrow(o))) {
    f <- engine$.bnn_tail_factor(o$M[i],o$C[i])
    errors <- abs(c(f$r,f$eta_mean,f$log_normalizer,f$entropy_eta)-
                    as.numeric(o[i,c("r","eta","logZ","entropy")]))
    stopifnot(all(is.finite(errors)),all(errors<=c(2e-8,2e-8,2e-6,2e-6)))
  }
  invisible(TRUE)
}
