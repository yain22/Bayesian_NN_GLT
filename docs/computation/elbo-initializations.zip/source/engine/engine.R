# Gaussian experiment adapter for the frozen coefficient-wise package engine.
# The engine receives only training-standardized data and the common initializer.
coef_v3_load <- function(source_root = ".") {
  directory <- file.path(source_root, "extensions", "coefficient_v3", "R")
  if (!dir.exists(directory)) directory <- file.path(source_root, "R")
  files <- c("engine-classification.R", "engine-coefficients.R", "engine-fit.R",
             "engine-network.R", "engine-priors.R", "engine-quadrature.R", "gltbnn.R")
  paths <- file.path(directory, files)
  if (!all(file.exists(paths))) stop("Incomplete coefficient-wise numerical source snapshot.")
  engine <- new.env(parent = baseenv())
  for (path in paths) sys.source(path, envir = engine)
  engine
}

coef_v3_fit <- function(x, y, W, prior, e = NULL, seed = 1L, control = list(),
                        progress = NULL, fixed_shape = NULL, batches = NULL,
                        milestones = integer(), on_milestone = NULL) {
  if (is.null(e) || !is.function(e$.gltbnn_engine_fit)) e <- coef_v3_load()
  prior <- switch(tolower(prior), g = "G", gl = "GL", hs = "GL", glt = "GLT",
                  stop("Choose the G, GL or GLT coefficient prior."))
  x <- e$.gltbnn_matrix(x, "x")
  if (!is.numeric(y) || !is.null(dim(y)) || length(y) != nrow(x) || any(!is.finite(y))) {
    stop("Supply one finite numeric response per training row.")
  }
  prep <- list(x_center = colMeans(x), x_scale = apply(x, 2L, stats::sd),
               y_center = mean(y), y_scale = stats::sd(y))
  if (any(!is.finite(c(prep$x_scale, prep$y_scale)) | c(prep$x_scale, prep$y_scale) <= 0)) {
    stop("Supply variable training predictors and response.")
  }
  xx <- e$.gltbnn_scale_x(x, prep)
  yy <- (y - prep$y_center) / prep$y_scale
  if (!is.list(W) || length(W) < 2L || !all(vapply(W, is.matrix, logical(1)))) {
    stop("Supply the hidden-layer and output matrices of the common initializer.")
  }
  widths <- vapply(W, nrow, integer(1))
  hidden <- widths[-length(widths)]
  if (any(widths < 1L) || tail(widths, 1L) != 1L ||
      any(vapply(W, ncol, integer(1)) != c(ncol(x), hidden) + 1L) ||
      any(!vapply(W, function(w) is.numeric(w) && all(is.finite(w)), logical(1)))) {
    stop("Initializer dimensions must match the augmented inputs and scalar output.")
  }
  report <- progress
  if (is.character(progress) && length(progress) == 1L) {
    report <- function(row) {
      cat(sprintf("outer=%d elbo_mc=%.10f accepted=%d rejected=%d seconds=%.1f\n",
                  row$outer, row$elbo, row$accepted, row$rejected, row$seconds),
          file = progress, append = TRUE)
    }
  }
  if (!is.null(report) && !is.function(report)) stop("Supply a progress function or log filename.")
  ctl <- e$.gltbnn_control(control)
  attach_preprocess <- function(fit) {
    fit$preprocess <- prep
    fit$config$batch_protocol <- if (is.null(batches)) "full" else "repeated_permutation"
    fit
  }
  milestone <- if (is.function(on_milestone)) {
    function(outer, fit) on_milestone(outer, attach_preprocess(fit))
  }
  fit <- e$.gltbnn_engine_fit(xx, yy, hidden, prior, ctl, seed, geometry = "coefficient",
                              initial_weights = W, progress = report, fixed_shape = fixed_shape,
                              batches = batches, milestones = milestones, on_milestone = milestone)
  attach_preprocess(fit)
}

coef_v3_predict <- function(fit, newx, draws = 256L, seed = 1L, predictive = FALSE,
                            e = NULL, block = 2048L) {
  if (is.null(e) || !is.function(e$.bnn_draw_weights)) e <- coef_v3_load()
  draws <- e$.gltbnn_integer(draws, "draws", minimum = 2L)
  block <- e$.gltbnn_integer(block, "block")
  x <- e$.gltbnn_matrix(newx, "newx")
  if (ncol(x) != fit$config$p) stop("Test predictors must match the training columns.")
  x <- e$.gltbnn_scale_x(x, fit$preprocess)
  set.seed(as.integer(as.double(seed) %% 2147483646 + 1))
  # Reuse each draw of W for all test rows, including across row blocks.
  latent <- matrix(NA_real_, nrow = draws, ncol = nrow(x))
  for (j in seq_len(draws)) {
    W <- e$.bnn_draw_weights(fit$parameters, e$.bnn_normal_draw(fit$parameters))
    for (lo in seq.int(1L, nrow(x), by = block)) {
      ids <- lo:min(nrow(x), lo + block - 1L)
      latent[j, ids] <- e$.bnn_forward(x[ids, , drop = FALSE], W)$y
    }
  }
  latent <- latent * fit$preprocess$y_scale + fit$preprocess$y_center
  result <- list(mean = colMeans(latent), mcse = apply(latent, 2L, stats::sd) / sqrt(draws),
                 latent_draws = latent)
  if (predictive) {
    set.seed(as.integer((as.double(seed) + 104729) %% 2147483646 + 1))
    precision <- stats::rgamma(draws, shape = fit$state$noise$a, rate = fit$state$noise$b)
    result$sd_draw <- fit$preprocess$y_scale / sqrt(precision)
    result$response_draws <- latent + matrix(stats::rnorm(length(latent)), nrow = draws) * result$sd_draw
  }
  result
}
