# Matched simulation of coefficientwise shrinkage on the archived study design.
v3_sim_setup <- function(root, engine_dir) {
  snapshot <- file.path(dirname(engine_dir),"study")
  sys.source(file.path(snapshot,"extensions/relu_ejs_v1/run.R"),.GlobalEnv)
  ejs_load(snapshot)
  sys.source(file.path(engine_dir, "engine.R"), .GlobalEnv)
  sys.source(file.path(dirname(engine_dir),"tail_audit.R"),.GlobalEnv)
  observe_tail_engine(coef_v3_load(engine_dir))
}

v3_sim_manifest <- function(root) {
  base <- file.path(root,"outputs/continuous_v2/simulation/relu_ejs_v1")
  inputs <- read.csv(file.path(base,"calibration.csv"), stringsAsFactors=FALSE)
  stopifnot(nrow(inputs)==1600L, all(table(inputs$cell,inputs$snr)==100L),
            !anyDuplicated(inputs[c("cell","snr","replicate")]))
  arch <- expand.grid(depth=c(2L,5L,10L),width=c(10L,25L))
  jobs <- merge(inputs,arch,by=NULL)
  jobs$file <- file.path(base,paste0("snr",jobs$snr),"data",sprintf("c%d_r%03d.rds",jobs$cell,jobs$replicate))
  jobs$key <- sprintf("s%d_c%02d_r%03d_d%02dw%02d",jobs$snr,jobs$cell,jobs$replicate,jobs$depth,jobs$width)
  jobs <- jobs[order(jobs$replicate,jobs$width,jobs$depth,jobs$cell,jobs$snr),]
  stopifnot(nrow(jobs)==9600L,!anyDuplicated(jobs$key))
  jobs
}

v3_save_once <- function(object, file) {
  dir.create(dirname(file),showWarnings=FALSE,recursive=TRUE)
  if (file.exists(file)) stop("Unexpected existing checkpoint: ",basename(file))
  tmp <- tempfile("partial-",tmpdir=dirname(file))
  on.exit(unlink(tmp))
  saveRDS(object,tmp,compress=TRUE)
  if (!file.rename(tmp,file)) stop("Could not commit checkpoint.")
}

v3_interval <- function(x,target) {
  bands <- apply(x,2L,stats::quantile,probs=c(.05,.95),names=FALSE)
  c(coverage=mean(target>=bands[1,] & target<=bands[2,]),width=mean(bands[2,]-bands[1,]))
}

v3_shrinkage <- function(fit, active, e) {
  # Match first-layer coordinates to observed predictors; exclude the bias.
  K <- fit$config$K[1L]; p <- fit$config$p
  terms <- e$.bnn_prior_terms(fit$state$g[[1L]],K*(p+1L),fit$config$prior)
  logsd <- matrix((fit$state$noise$zeta+terms$logvar)/2,K,p+1L)[,seq_len(p),drop=FALSE]
  q <- function(z,prob) stats::quantile(z,prob,names=FALSE)
  within <- apply(logsd,1L,function(x) q(x,.9)-q(x,.1))
  c(active_median_log_sd_q=stats::median(logsd[,seq_len(active),drop=FALSE]),
    inactive_median_log_sd_q=if(active<p)stats::median(logsd[,-seq_len(active),drop=FALSE]) else NA_real_,
    within_unit_log_ratio=stats::median(within))
}

v3_sim_run <- function(job, out, e, seal) {
  near <- job$replicate==1L
  folder <- file.path(out,"main",sprintf("snr%d_d%dw%d",job$snr,job$depth,job$width),
                      sprintf("c%d",job$cell),job$key)
  methods <- c("g","hs","glt","fnn","dropout","l1")
  files <- file.path(folder,paste0(methods,".rds"))
  expected <- function(z,m) identical(z$seal,seal) && identical(z$key,job$key) &&
    identical(z$method,m) && identical(z$data_md5,job$data_md5) && is.finite(z$metrics[["rmse"]])
  done <- file.exists(files)
  for(i in which(done)) stopifnot(expected(readRDS(files[i]),methods[i]))
  if (all(done)) return(6L)
  stopifnot(identical(unname(tools::md5sum(job$file)),job$data_md5))
  d <- readRDS(job$file)
  stopifnot(d$cell$id==job$cell,d$replicate==job$replicate,nrow(d$test$x)==2000L,
            abs(ejs_ratio(d$train)-job$snr)<1e-10)
  K <- rep(job$width,job$depth)
  pp <- sn_preprocess(d$train$x,d$train$y)
  x <- sn_x(d$train$x,pp)
  y <- (d$train$y-pp$y_center)/pp$y_scale
  initial_seed <- tabnn_seed("cavi100_v1",job$cell,job$replicate,"initial")
  vi_seed <- tabnn_seed("relu100_v1",job$cell,job$replicate,"variational")
  pred_seed <- tabnn_seed(initial_seed,"predict")
  W <- cb_train(x,y,K,initial_seed,600L)
  init_sha <- digest::digest(W,algo="sha256")
  for (i in which(!done)) {
    m <- methods[i]
    started <- proc.time()[[3L]]
    record <- list(seal=seal,key=job$key,method=m,data_md5=job$data_md5,init_sha=init_sha,
      initial_seed=initial_seed,vi_seed=vi_seed,pred_seed=pred_seed)
    if (m %in% c("g","hs","glt")) {
      fit <- coef_v3_fit(d$train$x,d$train$y,W,m,e=e,seed=vi_seed,control=snr1_control)
      stopifnot(fit$config$geometry=="coefficient",fit$outer==60L,nrow(fit$weight_steps)==600L,
                identical(fit$config$K,K),all(is.finite(fit$trace$elbo)),is.finite(fit$endpoint$value))
      uq <- job$cell==2L
      draw <- coef_v3_predict(fit,d$test$x,256L,pred_seed,predictive=uq,e=e)
      mu <- draw$mean
      record$scale <- v3_shrinkage(fit,d$cell$s,e)
      if(m=="glt") record$tail_audit <- fit$tail_audit
      record$trace <- fit$trace
      record$endpoint <- fit$endpoint[c("value","mcse")]
      if (uq) record$uq <- setNames(c(v3_interval(draw$latent_draws,d$test$truth),
                              v3_interval(draw$response_draws,d$test$y)),
                              c("mean_coverage","mean_width","response_coverage","response_width"))
      if (near) record$fit <- fit
    } else {
      w <- cb_train(x,y,K,tabnn_seed(initial_seed,m),600L,rate=if(m=="dropout") .2 else 0,
                    l1=if(m=="l1") .001 else 0,W=W)
      mu <- cb_forward(sn_x(d$test$x,pp),w)$y*pp$y_scale+pp$y_center
      if (near) record$weights <- w
    }
    stopifnot(length(mu)==length(d$test$y),all(is.finite(mu)))
    record$metrics <- c(rmse=sqrt(mean((mu-d$test$y)^2)),mean_rmse=sqrt(mean((mu-d$test$truth)^2)))
    record$seconds <- proc.time()[[3L]]-started
    if (near) record$prediction <- mu
    stopifnot(expected(record,m))
    v3_save_once(record,files[i])
  }
  6L
}
