# Reproducing the ten-initialization ELBO figure

Open `multistart/README.md` for the fitting design and commands to verify the nine synthetic training sets, regenerate Figure S11 from the saved traces, or refit the 270 networks. The rendered figure is `multistart/v3_elbo_current.pdf`. The `source/` directory contains the R routines used for those fits.
